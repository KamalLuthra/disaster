import { type User, type InsertUser, type Report, type InsertReport } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Report methods
  getAllReports(): Promise<Report[]>;
  getReportById(id: string): Promise<Report | undefined>;
  createReport(report: InsertReport): Promise<Report>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private reports: Map<string, Report>;

  constructor() {
    this.users = new Map();
    this.reports = new Map();
    this.seedDemoData();
  }

  private seedDemoData() {
    // Add demo reports for hackathon presentation
    const demoReports: Report[] = [
      {
        id: randomUUID(),
        category: "flood",
        title: "Severe flooding in residential area",
        description: "Heavy rainfall has caused severe flooding in the residential area near Saket. Water level is approximately 4 feet high. Multiple families are stranded on rooftops. Immediate evacuation assistance needed.",
        location: "Saket Metro Station, New Delhi",
        latitude: 28.5244,
        longitude: 77.2066,
        severityLevel: "critical",
        imageUrl: null,
        aiAnalysis: "Critical flooding situation requiring immediate evacuation and rescue operations. Multiple families at risk.",
        suggestedActions: JSON.stringify([
          "Deploy rescue boats immediately",
          "Evacuate residents to higher ground",
          "Set up emergency shelter",
          "Coordinate with fire department"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      },
      {
        id: randomUUID(),
        category: "fire",
        title: "Building fire at commercial complex",
        description: "Fire broke out at a commercial building in Connaught Place. Smoke visible from multiple floors. Fire department on site. Some people still trapped inside the building.",
        location: "Connaught Place, Central Delhi",
        latitude: 28.6315,
        longitude: 77.2167,
        severityLevel: "high",
        imageUrl: null,
        aiAnalysis: "Active fire situation with potential casualties. Immediate fire response required.",
        suggestedActions: JSON.stringify([
          "Emergency fire response ongoing",
          "Evacuate surrounding buildings",
          "Ambulances on standby",
          "Block traffic in the area"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
      {
        id: randomUUID(),
        category: "medical",
        title: "Mass food poisoning incident",
        description: "Approximately 30 people showing symptoms of food poisoning after attending a community event. Symptoms include vomiting, diarrhea, and stomach cramps. Local clinic overwhelmed.",
        location: "Dwarka Sector 12 Community Center",
        latitude: 28.5921,
        longitude: 77.0460,
        severityLevel: "high",
        imageUrl: null,
        aiAnalysis: "Mass casualty medical emergency requiring additional medical resources and investigation.",
        suggestedActions: JSON.stringify([
          "Send additional ambulances",
          "Alert nearby hospitals",
          "Health department investigation needed",
          "Set up temporary medical station"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
      },
      {
        id: randomUUID(),
        category: "infrastructure",
        title: "Bridge structural damage reported",
        description: "Visible cracks and structural damage observed on the pedestrian bridge near Kashmere Gate. Bridge is still in use but appears unsafe. Risk of collapse.",
        location: "Kashmere Gate Metro Station",
        latitude: 28.6679,
        longitude: 77.2273,
        severityLevel: "medium",
        imageUrl: null,
        aiAnalysis: "Infrastructure safety concern requiring inspection and possible closure.",
        suggestedActions: JSON.stringify([
          "Send structural engineer for inspection",
          "Consider temporary closure",
          "Divert pedestrian traffic",
          "Install warning signs"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      },
      {
        id: randomUUID(),
        category: "missing_person",
        title: "Child separated from family at crowded market",
        description: "A 6-year-old boy was separated from his family at Chandni Chowk market. Wearing blue shirt and black pants. Family is extremely distressed. Child speaks Hindi.",
        location: "Chandni Chowk Market",
        latitude: 28.6506,
        longitude: 77.2303,
        severityLevel: "high",
        imageUrl: null,
        aiAnalysis: "Missing child case requiring immediate search and coordination with local authorities.",
        suggestedActions: JSON.stringify([
          "Alert local police",
          "Coordinate with market security",
          "Broadcast description to nearby areas",
          "Check nearby police stations"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 20), // 20 minutes ago
      },
      {
        id: randomUUID(),
        category: "infrastructure",
        title: "Water main break causing road flooding",
        description: "Major water main break on MG Road. Water gushing out and flooding the road. Traffic severely impacted. Water supply to nearby areas disrupted.",
        location: "MG Road, Gurgaon",
        latitude: 28.4595,
        longitude: 77.0266,
        severityLevel: "medium",
        imageUrl: null,
        aiAnalysis: "Infrastructure failure requiring immediate repair and traffic management.",
        suggestedActions: JSON.stringify([
          "Contact water utility for repair",
          "Set up traffic diversions",
          "Notify affected residents",
          "Deploy pumps to clear water"
        ]),
        isSpam: 0,
        reportedAt: new Date(Date.now() - 1000 * 60 * 90), // 1.5 hours ago
      },
    ];

    demoReports.forEach(report => {
      this.reports.set(report.id, report);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Report methods
  async getAllReports(): Promise<Report[]> {
    return Array.from(this.reports.values()).sort(
      (a, b) => new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime()
    );
  }

  async getReportById(id: string): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = randomUUID();
    const report: Report = {
      ...insertReport,
      id,
      reportedAt: new Date(),
      severityLevel: insertReport.severityLevel || "medium",
      imageUrl: insertReport.imageUrl || null,
      aiAnalysis: insertReport.aiAnalysis || null,
      suggestedActions: insertReport.suggestedActions || null,
      isSpam: insertReport.isSpam ?? 0,
    };
    this.reports.set(id, report);
    return report;
  }
}

export const storage = new MemStorage();
