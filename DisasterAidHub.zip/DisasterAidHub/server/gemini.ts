import { GoogleGenAI } from "@google/genai";

// Using Gemini AI integration blueprint
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface ReportAnalysis {
  severityLevel: "critical" | "high" | "medium" | "low" | "info";
  isSpam: boolean;
  suggestedActions: string[];
  analysis: string;
}

export async function analyzeDisasterReport(
  category: string,
  title: string,
  description: string,
  location: string
): Promise<ReportAnalysis> {
  try {
    const systemPrompt = `You are an emergency management AI assistant. Analyze disaster reports and assess their severity.

For each report, provide:
1. Severity level (critical/high/medium/low/info)
2. Whether it's spam or a real emergency
3. Suggested emergency response actions
4. Brief analysis

Severity guidelines:
- CRITICAL: Immediate life-threatening situations, mass casualties, major infrastructure collapse
- HIGH: Serious emergencies requiring urgent response, injuries, significant damage
- MEDIUM: Important incidents requiring attention, minor injuries, moderate damage
- LOW: Non-urgent situations, no immediate danger
- INFO: General information, no emergency response needed

Respond with JSON in this exact format:
{
  "severityLevel": "critical|high|medium|low|info",
  "isSpam": false,
  "suggestedActions": ["action1", "action2", "action3"],
  "analysis": "Brief assessment of the situation"
}`;

    const prompt = `Analyze this disaster report:
Category: ${category}
Title: ${title}
Description: ${description}
Location: ${location}

Provide severity assessment, spam detection, and suggested emergency response actions.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            severityLevel: { 
              type: "string",
              enum: ["critical", "high", "medium", "low", "info"]
            },
            isSpam: { type: "boolean" },
            suggestedActions: { 
              type: "array",
              items: { type: "string" }
            },
            analysis: { type: "string" },
          },
          required: ["severityLevel", "isSpam", "suggestedActions", "analysis"],
        },
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
    });

    // Get the text response - the SDK provides response.text as a property
    const rawJson = response.text;
    
    if (rawJson) {
      const data: ReportAnalysis = JSON.parse(rawJson);
      return data;
    } else {
      throw new Error("Empty response from AI model");
    }
  } catch (error) {
    console.error("AI analysis error:", error);
    // Fallback to default values if AI fails
    return {
      severityLevel: "medium",
      isSpam: false,
      suggestedActions: ["Contact local emergency services", "Monitor the situation"],
      analysis: "Unable to perform AI analysis. Manual review recommended.",
    };
  }
}
