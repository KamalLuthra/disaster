import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReportSchema } from "@shared/schema";
import { analyzeDisasterReport } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all disaster reports
  app.get("/api/reports", async (_req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  // Get single report by ID
  app.get("/api/reports/:id", async (req, res) => {
    try {
      const report = await storage.getReportById(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      console.error("Error fetching report:", error);
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  // Create new disaster report with AI analysis
  app.post("/api/reports", async (req, res) => {
    try {
      // Validate request body
      const validationResult = insertReportSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }

      const reportData = validationResult.data;

      // Analyze report with AI if API key is available
      let aiAnalysis;
      let suggestedActions;
      let severityLevel = reportData.severityLevel || "medium";
      let isSpam = 0;

      if (process.env.GEMINI_API_KEY) {
        try {
          const analysis = await analyzeDisasterReport(
            reportData.category,
            reportData.title,
            reportData.description,
            reportData.location
          );

          severityLevel = analysis.severityLevel;
          isSpam = analysis.isSpam ? 1 : 0;
          aiAnalysis = analysis.analysis;
          suggestedActions = JSON.stringify(analysis.suggestedActions);
        } catch (error) {
          console.error("AI analysis failed, using defaults:", error);
        }
      }

      // Create report with AI insights
      const report = await storage.createReport({
        ...reportData,
        severityLevel,
        isSpam,
        aiAnalysis,
        suggestedActions,
      });

      res.status(201).json(report);
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ error: "Failed to create report" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
