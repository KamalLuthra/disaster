import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Disaster Report Schema
export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: varchar("category", { length: 50 }).notNull(), // flood, fire, medical, infrastructure, missing_person
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(), // address or description
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  severityLevel: varchar("severity_level", { length: 20 }).notNull(), // critical, high, medium, low, info
  imageUrl: text("image_url"),
  aiAnalysis: text("ai_analysis"), // JSON string with AI insights
  suggestedActions: text("suggested_actions"), // JSON array of actions
  isSpam: integer("is_spam").default(0), // 0 = not spam, 1 = spam
  reportedAt: timestamp("reported_at").defaultNow().notNull(),
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  reportedAt: true,
}).extend({
  category: z.enum(["flood", "fire", "medical", "infrastructure", "missing_person"]),
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  location: z.string().min(3, "Location is required"),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  severityLevel: z.enum(["critical", "high", "medium", "low", "info"]).optional(),
  imageUrl: z.string().optional(),
  aiAnalysis: z.string().optional(),
  suggestedActions: z.string().optional(),
  isSpam: z.number().optional(),
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

// Keep existing user schema
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
