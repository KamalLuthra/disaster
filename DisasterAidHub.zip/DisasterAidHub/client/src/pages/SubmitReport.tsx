import { ReportForm } from "@/components/ReportForm";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { InsertReport } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function SubmitReport() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const createReportMutation = useMutation({
    mutationFn: async (data: InsertReport) => {
      await apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "Report submitted successfully",
        description: "Emergency responders have been notified. Thank you for keeping our community safe.",
      });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit report",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background px-4 py-3">
        <div className="flex items-center gap-4 max-w-2xl mx-auto">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-primary">Submit Report</h1>
            <p className="text-xs text-muted-foreground">Help your community stay safe</p>
          </div>
        </div>
      </header>

      <main className="p-4 py-8">
        <ReportForm 
          onSubmit={(data) => createReportMutation.mutateAsync(data)}
          isPending={createReportMutation.isPending}
        />
      </main>
    </div>
  );
}
