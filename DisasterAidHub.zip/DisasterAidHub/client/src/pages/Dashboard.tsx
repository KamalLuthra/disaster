import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DisasterMap } from "@/components/DisasterMap";
import { ReportCard } from "@/components/ReportCard";
import { FilterChips } from "@/components/FilterChips";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useLocation } from "wouter";
import { Report } from "@shared/schema";
import { AlertCircle, Plus, Loader2 } from "lucide-react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  const { data: reports = [], isLoading, error } = useQuery<Report[]>({
    queryKey: ["/api/reports"],
  });

  const filteredReports = selectedCategories.length === 0 
    ? reports 
    : reports.filter(r => selectedCategories.includes(r.category));

  const handleToggleCategory = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  return (
    <div className="flex flex-col h-screen">
      <header className="sticky top-0 z-50 border-b bg-background px-4 py-3">
        <div className="flex items-center justify-between gap-4 max-w-7xl mx-auto">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-primary" data-testid="text-app-title">
              DisasterWatch
            </h1>
            <p className="text-xs text-muted-foreground hidden sm:block">
              Real-time disaster reporting platform
            </p>
          </div>
          <Button 
            onClick={() => setLocation("/report")}
            className="gap-2"
            data-testid="button-new-report"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Report Incident</span>
            <span className="sm:hidden">Report</span>
          </Button>
        </div>
      </header>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        <div className="flex-1 flex flex-col p-4 gap-4">
          <div className="space-y-2">
            <h2 className="text-sm font-semibold">Filter by Category</h2>
            <FilterChips 
              selectedCategories={selectedCategories}
              onToggleCategory={handleToggleCategory}
            />
          </div>

          <div className="flex-1 relative rounded-md overflow-hidden border">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <DisasterMap reports={filteredReports} />
            )}
          </div>
        </div>

        <aside className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l bg-card flex flex-col">
          <div className="p-4 border-b">
            <h2 className="font-semibold text-lg" data-testid="text-report-count">
              Recent Reports ({filteredReports.length})
            </h2>
            <p className="text-xs text-muted-foreground">
              Live updates from your community
            </p>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-4 space-y-3">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Failed to load reports. Please refresh the page.
                  </AlertDescription>
                </Alert>
              )}

              {isLoading && (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              )}

              {!isLoading && filteredReports.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <p data-testid="text-no-reports">No reports found</p>
                  <p className="text-sm mt-2">Be the first to report an incident</p>
                </div>
              )}

              {filteredReports.map((report) => (
                <ReportCard key={report.id} report={report} />
              ))}
            </div>
          </ScrollArea>
        </aside>
      </div>
    </div>
  );
}
