import { Badge } from "@/components/ui/badge";
import { Flame, Droplets, HeartPulse, Wrench, UserX, X } from "lucide-react";

interface FilterChipsProps {
  selectedCategories: string[];
  onToggleCategory: (category: string) => void;
}

const categories = [
  { value: "flood", label: "Flood", icon: Droplets },
  { value: "fire", label: "Fire", icon: Flame },
  { value: "medical", label: "Medical", icon: HeartPulse },
  { value: "infrastructure", label: "Infrastructure", icon: Wrench },
  { value: "missing_person", label: "Missing Person", icon: UserX },
];

export function FilterChips({ selectedCategories, onToggleCategory }: FilterChipsProps) {
  return (
    <div className="flex flex-wrap gap-2" data-testid="filter-chips-container">
      {categories.map((category) => {
        const Icon = category.icon;
        const isSelected = selectedCategories.includes(category.value);
        
        return (
          <Badge
            key={category.value}
            variant={isSelected ? "default" : "outline"}
            className="cursor-pointer px-3 py-1.5 hover-elevate active-elevate-2"
            onClick={() => onToggleCategory(category.value)}
            data-testid={`filter-chip-${category.value}`}
          >
            <Icon className="w-3 h-3 mr-1" />
            {category.label}
            {isSelected && <X className="w-3 h-3 ml-1" />}
          </Badge>
        );
      })}
    </div>
  );
}
