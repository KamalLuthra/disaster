import { useEffect, useRef } from "react";
import type { Report } from "@shared/schema";

interface DisasterMapProps {
  reports: Report[];
  onMarkerClick?: (report: Report) => void;
  center?: [number, number];
  zoom?: number;
}

const severityColors = {
  critical: "#dc2626",
  high: "#ea580c",
  medium: "#f59e0b",
  low: "#3b82f6",
  info: "#6b7280",
};

export function DisasterMap({ reports, onMarkerClick, center = [28.6139, 77.2090], zoom = 12 }: DisasterMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const L = (window as any).L;
    if (!L) return;

    const map = L.map(mapRef.current).setView(center, zoom);
    
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapInstanceRef.current;
    const L = (window as any).L;
    if (!map || !L) return;

    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    reports.forEach(report => {
      if (report.isSpam) return;

      const color = severityColors[report.severityLevel as keyof typeof severityColors] || severityColors.info;
      
      const icon = L.divIcon({
        className: "custom-marker",
        html: `
          <div style="
            background: ${color};
            width: 32px;
            height: 32px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            border: 3px solid white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
          ">
            <div style="
              width: 12px;
              height: 12px;
              background: white;
              border-radius: 50%;
              transform: rotate(45deg);
            "></div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
      });

      const marker = L.marker([report.latitude, report.longitude], { icon })
        .addTo(map)
        .bindPopup(`
          <div style="min-width: 200px;">
            <h3 style="font-weight: 600; margin: 0 0 8px 0; font-size: 14px;">${report.title}</h3>
            <p style="margin: 4px 0; font-size: 12px; color: #666;">${report.category.replace('_', ' ').toUpperCase()}</p>
            <p style="margin: 4px 0; font-size: 12px;"><strong>Severity:</strong> ${report.severityLevel.toUpperCase()}</p>
          </div>
        `);

      if (onMarkerClick) {
        marker.on("click", () => onMarkerClick(report));
      }

      markersRef.current.push(marker);
    });
  }, [reports, onMarkerClick]);

  return (
    <div 
      ref={mapRef} 
      className="w-full h-full min-h-[500px] rounded-md"
      data-testid="map-container"
    />
  );
}
