import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Report } from "@shared/schema";
import { Flame, Droplets, HeartPulse, Wrench, UserX, MapPin, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ReportCardProps {
  report: Report;
  onClick?: () => void;
}

const categoryIcons = {
  flood: Droplets,
  fire: Flame,
  medical: HeartPulse,
  infrastructure: Wrench,
  missing_person: UserX,
};

const categoryColors = {
  flood: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  fire: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  medical: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
  infrastructure: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  missing_person: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
};

const severityVariants = {
  critical: "destructive",
  high: "destructive",
  medium: "default",
  low: "secondary",
  info: "outline",
} as const;

export function ReportCard({ report, onClick }: ReportCardProps) {
  const Icon = categoryIcons[report.category as keyof typeof categoryIcons] || Flame;
  const categoryColor = categoryColors[report.category as keyof typeof categoryColors];

  return (
    <Card 
      className="hover-elevate active-elevate-2 cursor-pointer transition-all"
      onClick={onClick}
      data-testid={`card-report-${report.id}`}
    >
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <Badge className={categoryColor} data-testid={`badge-category-${report.id}`}>
            <Icon className="w-3 h-3 mr-1" />
            {report.category.replace('_', ' ')}
          </Badge>
          <Badge 
            variant={severityVariants[report.severityLevel as keyof typeof severityVariants]}
            data-testid={`badge-severity-${report.id}`}
          >
            {report.severityLevel}
          </Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground whitespace-nowrap">
          <Clock className="w-3 h-3" />
          <span data-testid={`text-time-${report.id}`}>
            {formatDistanceToNow(new Date(report.reportedAt), { addSuffix: true })}
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <h3 className="font-semibold text-base line-clamp-1" data-testid={`text-title-${report.id}`}>
          {report.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-description-${report.id}`}>
          {report.description}
        </p>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="w-3 h-3" />
          <span className="line-clamp-1" data-testid={`text-location-${report.id}`}>
            {report.location}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
